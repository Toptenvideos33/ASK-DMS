import { useStore, qtyLabel, formatLKR, type Bill } from "@/lib/store";

export function Receipt({ bill, width = 80 }: { bill: Bill; width?: 58 | 80 }) {
  const { products, settings, drivers } = useStore.getState();
  const driver = drivers.find((d) => d.id === bill.driverId);

  return (
    <div className={`receipt ${width === 58 ? "receipt-58" : "receipt-80"}`}>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontWeight: 700, fontSize: width === 58 ? 12 : 14 }}>{settings.businessName}</div>
        <div>{settings.address}</div>
        <div>Tel: {settings.phone1}{settings.phone2 ? ` / ${settings.phone2}` : ""}</div>
      </div>
      <hr />
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <span>Invoice:</span><span>{bill.invoiceNo}</span>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <span>Date:</span><span>{new Date(bill.createdAt).toLocaleString()}</span>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <span>Driver:</span><span>{driver?.name ?? "-"}</span>
      </div>
      <hr />
      <div><b>Bill To:</b> {bill.shopName}</div>
      {bill.shopPhone && <div>Tel: {bill.shopPhone}</div>}
      {bill.shopAddress && <div>{bill.shopAddress}</div>}
      <hr />
      <div style={{ display: "flex", fontWeight: 700 }}>
        <span style={{ flex: 1 }}>Item</span>
        <span style={{ width: 50, textAlign: "right" }}>Qty</span>
        <span style={{ width: width === 58 ? 50 : 70, textAlign: "right" }}>Amount</span>
      </div>
      <hr />
      {bill.items.map((it, i) => {
        const p = products.find((x) => x.id === it.productId);
        return (
          <div key={i} style={{ marginBottom: 4 }}>
            <div style={{ display: "flex" }}>
              <span style={{ flex: 1 }}>{p?.name ?? it.productId}</span>
              <span style={{ width: 50, textAlign: "right" }}>{qtyLabel(it.cases, it.units)}</span>
              <span style={{ width: width === 58 ? 50 : 70, textAlign: "right" }}>{it.lineTotal.toFixed(2)}</span>
            </div>
            {it.focUnits > 0 && (
              <div style={{ paddingLeft: 8, opacity: 0.85 }}>+ FOC: {it.focUnits}U free</div>
            )}
            {it.discountPercent > 0 && (
              <div style={{ paddingLeft: 8, opacity: 0.85 }}>- Disc: {it.discountPercent}%</div>
            )}
          </div>
        );
      })}
      <hr />
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <span>Subtotal</span><span>{bill.subtotal.toFixed(2)}</span>
      </div>
      {bill.taxAmount > 0 && (
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span>{settings.taxLabel} ({bill.taxPercent}%)</span><span>{bill.taxAmount.toFixed(2)}</span>
        </div>
      )}
      <div style={{ display: "flex", justifyContent: "space-between", fontWeight: 700, fontSize: width === 58 ? 12 : 14, marginTop: 4 }}>
        <span>TOTAL (LKR)</span><span>{formatLKR(bill.total).replace("Rs. ", "")}</span>
      </div>
      <hr />
      <div>Payment: <b>{bill.paymentMethod}</b></div>
      <hr />
      <div style={{ textAlign: "center" }}>
        <div>Thank you for your business!</div>
        <div style={{ marginTop: 4, opacity: 0.8 }}>Powered by ASK DMS</div>
      </div>
    </div>
  );
}
