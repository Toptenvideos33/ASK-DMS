import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Product = {
  id: string;
  name: string;
  sku: string;
  category: string;
  unitsPerCase: number;
  pricePerCase: number;
  pricePerUnit: number;
  stock: number; // in loose units (warehouse)
  // Auto FOC/discount: e.g. buy N cases get M units free, or % off when qty >= X
  focBuyCases?: number; // buy this many cases
  focFreeUnits?: number; // get this many units free
  discountMinCases?: number;
  discountPercent?: number;
};

export type Vehicle = {
  id: string;
  number: string;
  capacity: number;
  driverId?: string;
};

export type Driver = {
  id: string;
  name: string;
  phone: string;
  vehicleId?: string;
  routeId?: string;
};

export type Route = {
  id: string;
  name: string;
  area: string;
  stops: number;
};

export type LorryStockItem = { productId: string; units: number };

export type BillItem = {
  productId: string;
  cases: number;
  units: number;
  focUnits: number;
  discountPercent: number;
  lineTotal: number;
};

export type PaymentMethod = "Cash" | "Credit" | "Cheque" | "Bank Transfer";

export type Bill = {
  id: string;
  invoiceNo: string;
  createdAt: string;
  driverId: string;
  shopName: string;
  shopPhone: string;
  shopAddress?: string;
  items: BillItem[];
  subtotal: number;
  taxPercent: number;
  taxAmount: number;
  total: number;
  paymentMethod: PaymentMethod;
  notified: boolean;
};

export type Settings = {
  businessName: string;
  address: string;
  phone1: string;
  phone2: string;
  taxPercent: number;
  taxLabel: string;
};

type State = {
  products: Product[];
  vehicles: Vehicle[];
  drivers: Driver[];
  routes: Route[];
  lorryStock: LorryStockItem[];
  bills: Bill[];
  settings: Settings;
  invoiceCounter: number;

  addProduct: (p: Omit<Product, "id">) => void;
  updateProduct: (id: string, p: Partial<Product>) => void;
  deleteProduct: (id: string) => void;

  addVehicle: (v: Omit<Vehicle, "id">) => void;
  deleteVehicle: (id: string) => void;
  addDriver: (d: Omit<Driver, "id">) => void;
  deleteDriver: (id: string) => void;
  addRoute: (r: Omit<Route, "id">) => void;
  deleteRoute: (id: string) => void;

  setLorryStock: (productId: string, units: number) => void;
  stockOut: () => void; // return lorry stock to warehouse
  saveBill: (b: Omit<Bill, "id" | "invoiceNo" | "createdAt">) => Bill;
  markBillNotified: (id: string) => void;

  updateSettings: (s: Partial<Settings>) => void;
};

const uid = () => Math.random().toString(36).slice(2, 10);

const seedProducts: Product[] = [
  { id: "p1", name: "Yogurt Cup 80g", sku: "YOG-080", category: "Dairy", unitsPerCase: 48, pricePerCase: 2400, pricePerUnit: 55, stock: 1200, focBuyCases: 10, focFreeUnits: 6 },
  { id: "p2", name: "Fresh Milk 1L", sku: "MLK-1L", category: "Dairy", unitsPerCase: 12, pricePerCase: 2880, pricePerUnit: 250, stock: 360, discountMinCases: 5, discountPercent: 5 },
  { id: "p3", name: "Butter 250g", sku: "BTR-250", category: "Dairy", unitsPerCase: 24, pricePerCase: 9600, pricePerUnit: 420, stock: 240 },
  { id: "p4", name: "Ice Cream Tub 1L", sku: "ICE-1L", category: "Frozen", unitsPerCase: 8, pricePerCase: 6400, pricePerUnit: 850, stock: 96 },
  { id: "p5", name: "Cheese Slice 200g", sku: "CHE-200", category: "Dairy", unitsPerCase: 20, pricePerCase: 9000, pricePerUnit: 480, stock: 200 },
];

export const useStore = create<State>()(
  persist(
    (set, get) => ({
      products: seedProducts,
      vehicles: [
        { id: "v1", number: "WP-LM-3421", capacity: 200, driverId: "d1" },
        { id: "v2", number: "WP-PA-8812", capacity: 150, driverId: "d2" },
      ],
      drivers: [
        { id: "d1", name: "Kasun Perera", phone: "+94 71 234 5678", vehicleId: "v1", routeId: "r1" },
        { id: "d2", name: "Nimal Silva", phone: "+94 77 998 4421", vehicleId: "v2", routeId: "r2" },
      ],
      routes: [
        { id: "r1", name: "Colombo North", area: "Wellawatte → Bambalapitiya → Kollupitiya", stops: 18 },
        { id: "r2", name: "Negombo Coastal", area: "Ja-Ela → Negombo → Katunayake", stops: 22 },
      ],
      lorryStock: [
        { productId: "p1", units: 240 },
        { productId: "p2", units: 60 },
        { productId: "p3", units: 48 },
        { productId: "p4", units: 16 },
        { productId: "p5", units: 40 },
      ],
      bills: [],
      invoiceCounter: 1001,
      settings: {
        businessName: "ASK Distributions",
        address: "No. 42, Galle Road, Colombo 03, Sri Lanka",
        phone1: "+94 11 234 5678",
        phone2: "+94 77 123 4567",
        taxPercent: 0,
        taxLabel: "Tax",
      },

      addProduct: (p) => set((s) => ({ products: [...s.products, { ...p, id: uid() }] })),
      updateProduct: (id, p) =>
        set((s) => ({ products: s.products.map((x) => (x.id === id ? { ...x, ...p } : x)) })),
      deleteProduct: (id) => set((s) => ({ products: s.products.filter((x) => x.id !== id) })),

      addVehicle: (v) => set((s) => ({ vehicles: [...s.vehicles, { ...v, id: uid() }] })),
      deleteVehicle: (id) => set((s) => ({ vehicles: s.vehicles.filter((x) => x.id !== id) })),
      addDriver: (d) => set((s) => ({ drivers: [...s.drivers, { ...d, id: uid() }] })),
      deleteDriver: (id) => set((s) => ({ drivers: s.drivers.filter((x) => x.id !== id) })),
      addRoute: (r) => set((s) => ({ routes: [...s.routes, { ...r, id: uid() }] })),
      deleteRoute: (id) => set((s) => ({ routes: s.routes.filter((x) => x.id !== id) })),

      setLorryStock: (productId, units) =>
        set((s) => {
          const exists = s.lorryStock.find((x) => x.productId === productId);
          return {
            lorryStock: exists
              ? s.lorryStock.map((x) => (x.productId === productId ? { ...x, units } : x))
              : [...s.lorryStock, { productId, units }],
          };
        }),

      stockOut: () =>
        set((s) => {
          const updatedProducts = s.products.map((p) => {
            const lorry = s.lorryStock.find((l) => l.productId === p.id);
            return lorry ? { ...p, stock: p.stock + lorry.units } : p;
          });
          return { products: updatedProducts, lorryStock: s.lorryStock.map((l) => ({ ...l, units: 0 })) };
        }),

      saveBill: (b) => {
        const counter = get().invoiceCounter;
        const bill: Bill = {
          ...b,
          id: uid(),
          invoiceNo: `INV-${counter}`,
          createdAt: new Date().toISOString(),
        };
        set((s) => {
          // deduct lorry stock
          const lorry = [...s.lorryStock];
          for (const item of bill.items) {
            const totalUnits = item.cases * (s.products.find((p) => p.id === item.productId)?.unitsPerCase ?? 0) + item.units + item.focUnits;
            const idx = lorry.findIndex((l) => l.productId === item.productId);
            if (idx >= 0) lorry[idx] = { ...lorry[idx], units: Math.max(0, lorry[idx].units - totalUnits) };
          }
          return { bills: [bill, ...s.bills], invoiceCounter: counter + 1, lorryStock: lorry };
        });
        return bill;
      },

      markBillNotified: (id) =>
        set((s) => ({ bills: s.bills.map((b) => (b.id === id ? { ...b, notified: true } : b)) })),

      updateSettings: (s2) => set((s) => ({ settings: { ...s.settings, ...s2 } })),
    }),
    { name: "ask-dms-store" }
  )
);

// Helpers
export const formatLKR = (n: number) =>
  "Rs. " + n.toLocaleString("en-LK", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export const computeLineTotal = (
  product: Product,
  cases: number,
  units: number
): { focUnits: number; discountPercent: number; lineTotal: number } => {
  let focUnits = 0;
  if (product.focBuyCases && product.focFreeUnits && cases >= product.focBuyCases) {
    focUnits = Math.floor(cases / product.focBuyCases) * product.focFreeUnits;
  }
  const gross = cases * product.pricePerCase + units * product.pricePerUnit;
  let discountPercent = 0;
  if (product.discountMinCases && product.discountPercent && cases >= product.discountMinCases) {
    discountPercent = product.discountPercent;
  }
  const lineTotal = gross * (1 - discountPercent / 100);
  return { focUnits, discountPercent, lineTotal };
};

export const qtyLabel = (cases: number, units: number) => {
  if (cases && units) return `${cases}C + ${units}U`;
  if (cases) return `${cases} Case${cases > 1 ? "s" : ""}`;
  return `${units} Unit${units !== 1 ? "s" : ""}`;
};
