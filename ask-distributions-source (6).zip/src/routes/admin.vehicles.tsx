import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, Trash2, Truck } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/vehicles")({ component: VehiclesPage });

function VehiclesPage() {
  const { vehicles, drivers, addVehicle, deleteVehicle } = useStore();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ number: "", capacity: 100, driverId: "" });

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex items-end justify-between">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Fleet</div>
          <h1 className="text-3xl font-semibold mt-1">Vehicles</h1>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> Add Vehicle</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>New Vehicle</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label className="text-xs">Number Plate</Label><Input value={form.number} onChange={(e) => setForm({ ...form, number: e.target.value })} placeholder="WP-XX-1234" /></div>
              <div><Label className="text-xs">Capacity (cases)</Label><Input type="number" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: +e.target.value })} /></div>
              <div>
                <Label className="text-xs">Assigned Driver</Label>
                <select className="mt-1 w-full rounded-md border bg-background px-3 py-2 text-sm" value={form.driverId} onChange={(e) => setForm({ ...form, driverId: e.target.value })}>
                  <option value="">Unassigned</option>
                  {drivers.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
                </select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={() => { if (!form.number) return toast.error("Number plate required"); addVehicle({ ...form, driverId: form.driverId || undefined }); toast.success("Vehicle added"); setOpen(false); setForm({ number: "", capacity: 100, driverId: "" }); }}>Add</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {vehicles.map((v) => {
          const driver = drivers.find((d) => d.id === v.driverId);
          return (
            <Card key={v.id} className="p-5">
              <div className="flex items-start justify-between">
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary"><Truck className="h-5 w-5" /></div>
                <Button size="icon" variant="ghost" onClick={() => deleteVehicle(v.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
              <div className="mt-4 font-display text-xl font-semibold">{v.number}</div>
              <div className="text-sm text-muted-foreground">Capacity: {v.capacity} cases</div>
              <div className="mt-3 rounded-md bg-muted px-3 py-2 text-sm">
                <span className="text-muted-foreground">Driver: </span>
                <span className="font-medium">{driver?.name ?? "Unassigned"}</span>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
