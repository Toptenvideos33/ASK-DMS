import { createFileRoute, Outlet, Link, useRouterState } from "@tanstack/react-router";
import { Home, ReceiptText, Plus, ArrowLeft } from "lucide-react";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/driver")({ component: DriverLayout });

function DriverLayout() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const driver = useStore((s) => s.drivers[0]);

  const isHome = pathname === "/driver";
  const isBills = pathname === "/driver/bills";
  const isNew = pathname === "/driver/new-bill";

  return (
    <div className="min-h-screen bg-muted/40">
      <div className="mx-auto max-w-md min-h-screen bg-background flex flex-col shadow-[var(--shadow-elevated)] relative">
        {/* Driver app header */}
        <header className="px-5 pt-5 pb-4 text-primary-foreground" style={{ background: "var(--gradient-primary)" }}>
          <div className="flex items-center justify-between">
            <Link to="/" className="inline-flex items-center gap-1 text-xs opacity-80 hover:opacity-100">
              <ArrowLeft className="h-3.5 w-3.5" /> Launcher
            </Link>
            <span className="text-[11px] opacity-80">Driver App</span>
          </div>
          <div className="mt-3">
            <div className="text-xs opacity-80">Logged in as</div>
            <div className="font-display text-lg font-semibold">{driver?.name ?? "Driver"}</div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto pb-24">
          <Outlet />
        </main>

        {/* Bottom nav */}
        <nav className="absolute bottom-0 inset-x-0 border-t bg-card grid grid-cols-3">
          <TabLink to="/driver" active={isHome} icon={Home} label="Home" />
          <TabLink to="/driver/new-bill" active={isNew} icon={Plus} label="New Bill" highlight />
          <TabLink to="/driver/bills" active={isBills} icon={ReceiptText} label="Bills" />
        </nav>
      </div>
    </div>
  );
}

function TabLink({ to, active, icon: Icon, label, highlight }: { to: string; active: boolean; icon: any; label: string; highlight?: boolean }) {
  return (
    <Link
      to={to}
      className={`flex flex-col items-center justify-center gap-1 py-3 text-[11px] ${
        active ? "text-primary" : "text-muted-foreground"
      }`}
    >
      <div className={`grid place-items-center rounded-full ${highlight ? "h-10 w-10 bg-primary text-primary-foreground -mt-6 shadow-[var(--shadow-elevated)]" : "h-6 w-6"}`}>
        <Icon className={highlight ? "h-5 w-5" : "h-5 w-5"} />
      </div>
      <span className={highlight ? "mt-1" : ""}>{label}</span>
    </Link>
  );
}
