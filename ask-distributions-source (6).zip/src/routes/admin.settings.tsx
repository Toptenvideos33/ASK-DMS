import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/settings")({ component: SettingsPage });

function SettingsPage() {
  const { settings, updateSettings } = useStore();
  const [form, setForm] = useState(settings);

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <div className="text-xs uppercase tracking-wider text-muted-foreground">Configuration</div>
        <h1 className="text-3xl font-semibold mt-1">Business Settings</h1>
        <p className="text-sm text-muted-foreground mt-1">These details appear on every invoice header and customer notification.</p>
      </div>

      <Card className="p-6 space-y-4">
        <div>
          <Label className="text-xs">Business Name</Label>
          <Input value={form.businessName} onChange={(e) => setForm({ ...form, businessName: e.target.value })} />
        </div>
        <div>
          <Label className="text-xs">Address (Sri Lanka)</Label>
          <Textarea value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} rows={2} />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <Label className="text-xs">Phone 1</Label>
            <Input value={form.phone1} onChange={(e) => setForm({ ...form, phone1: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Phone 2</Label>
            <Input value={form.phone2} onChange={(e) => setForm({ ...form, phone2: e.target.value })} />
          </div>
        </div>

        <div className="border-t pt-4">
          <div className="text-xs font-semibold uppercase text-muted-foreground tracking-wider mb-2">Tax (optional)</div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label className="text-xs">Tax Label</Label>
              <Input value={form.taxLabel} onChange={(e) => setForm({ ...form, taxLabel: e.target.value })} placeholder="VAT / Tax" />
            </div>
            <div>
              <Label className="text-xs">Tax Percent</Label>
              <Input type="number" value={form.taxPercent} onChange={(e) => setForm({ ...form, taxPercent: +e.target.value })} />
            </div>
          </div>
          <p className="text-[11px] text-muted-foreground mt-2">Set 0 to disable. Currency is always LKR (Rs.).</p>
        </div>

        <div className="pt-2">
          <Button onClick={() => { updateSettings(form); toast.success("Settings saved"); }}>Save Changes</Button>
        </div>
      </Card>
    </div>
  );
}
