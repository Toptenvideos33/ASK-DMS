import { createFileRoute } from "@tanstack/react-router";
import { useStore, formatLKR, qtyLabel } from "@/lib/store";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/admin/reports")({ component: ReportsPage });

function ReportsPage() {
  const { bills, products, drivers } = useStore();
  const total = bills.reduce((s, b) => s + b.total, 0);
  const byPayment = bills.reduce<Record<string, number>>((acc, b) => {
    acc[b.paymentMethod] = (acc[b.paymentMethod] ?? 0) + b.total; return acc;
  }, {});

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <div className="text-xs uppercase tracking-wider text-muted-foreground">Insights</div>
        <h1 className="text-3xl font-semibold mt-1">Reports</h1>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="p-5"><div className="text-xs text-muted-foreground">Total Sales</div><div className="mt-2 text-2xl font-display font-semibold">{formatLKR(total)}</div></Card>
        <Card className="p-5"><div className="text-xs text-muted-foreground">Bills Issued</div><div className="mt-2 text-2xl font-display font-semibold">{bills.length}</div></Card>
        <Card className="p-5"><div className="text-xs text-muted-foreground">Cash Collected</div><div className="mt-2 text-2xl font-display font-semibold">{formatLKR(byPayment["Cash"] ?? 0)}</div></Card>
        <Card className="p-5"><div className="text-xs text-muted-foreground">Credit Outstanding</div><div className="mt-2 text-2xl font-display font-semibold">{formatLKR(byPayment["Credit"] ?? 0)}</div></Card>
      </div>

      <Card className="overflow-hidden p-0">
        <div className="border-b px-5 py-4"><h2 className="font-semibold">All Bills</h2></div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/60 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="text-left px-4 py-3">Invoice</th>
                <th className="text-left px-4 py-3">Shop</th>
                <th className="text-left px-4 py-3">Driver</th>
                <th className="text-left px-4 py-3">Items</th>
                <th className="text-left px-4 py-3">Payment</th>
                <th className="text-right px-4 py-3">Total</th>
                <th className="text-left px-4 py-3">Time</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {bills.length === 0 && (
                <tr><td colSpan={7} className="px-4 py-10 text-center text-muted-foreground">No bills yet.</td></tr>
              )}
              {bills.map((b) => {
                const d = drivers.find((x) => x.id === b.driverId);
                return (
                  <tr key={b.id}>
                    <td className="px-4 py-3 font-medium">{b.invoiceNo}</td>
                    <td className="px-4 py-3">{b.shopName}</td>
                    <td className="px-4 py-3 text-muted-foreground">{d?.name ?? "—"}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">
                      {b.items.map((it) => {
                        const p = products.find((x) => x.id === it.productId);
                        return `${p?.name ?? it.productId} (${qtyLabel(it.cases, it.units)})`;
                      }).join(", ")}
                    </td>
                    <td className="px-4 py-3">
                      <span className="rounded-full bg-muted px-2 py-0.5 text-xs">{b.paymentMethod}</span>
                    </td>
                    <td className="px-4 py-3 text-right font-medium">{formatLKR(b.total)}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{new Date(b.createdAt).toLocaleString()}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
