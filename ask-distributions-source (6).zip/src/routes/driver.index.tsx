import { createFileRoute, Link } from "@tanstack/react-router";
import { useStore, formatLKR } from "@/lib/store";
import { Plus, ReceiptText, Truck, Package } from "lucide-react";

export const Route = createFileRoute("/driver/")({ component: DriverHome });

function DriverHome() {
  const { bills, lorryStock, products } = useStore();
  const todayTotal = bills.reduce((s, b) => s + b.total, 0);
  const totalUnits = lorryStock.reduce((s, l) => s + l.units, 0);

  return (
    <div className="p-5 space-y-5">
      <div className="grid grid-cols-2 gap-3">
        <Stat label="Today's Sales" value={formatLKR(todayTotal)} icon={ReceiptText} />
        <Stat label="Bills" value={bills.length.toString()} icon={ReceiptText} />
        <Stat label="On Lorry" value={`${totalUnits} U`} icon={Truck} />
        <Stat label="SKUs" value={products.length.toString()} icon={Package} />
      </div>

      <Link
        to="/driver/new-bill"
        className="block rounded-2xl p-5 text-primary-foreground shadow-[var(--shadow-elevated)]"
        style={{ background: "var(--gradient-primary)" }}
      >
        <div className="flex items-center justify-between">
          <div>
            <div className="text-xs opacity-80">Start a delivery</div>
            <div className="text-xl font-semibold font-display mt-0.5">Create New Bill</div>
          </div>
          <div className="grid h-12 w-12 place-items-center rounded-full bg-white/20">
            <Plus className="h-6 w-6" />
          </div>
        </div>
      </Link>

      <div>
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-semibold text-sm">Recent Bills</h2>
          <Link to="/driver/bills" className="text-xs text-primary">See all</Link>
        </div>
        <div className="space-y-2">
          {bills.length === 0 && (
            <div className="rounded-xl border bg-card p-6 text-center text-sm text-muted-foreground">
              No bills today. Tap <b>Create New Bill</b> to start.
            </div>
          )}
          {bills.slice(0, 4).map((b) => (
            <div key={b.id} className="rounded-xl border bg-card p-3 flex items-center justify-between">
              <div>
                <div className="font-medium text-sm">{b.invoiceNo}</div>
                <div className="text-xs text-muted-foreground">{b.shopName} · {b.paymentMethod}</div>
              </div>
              <div className="text-right">
                <div className="font-semibold text-sm">{formatLKR(b.total)}</div>
                <div className="text-[10px] text-muted-foreground">{new Date(b.createdAt).toLocaleTimeString()}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, icon: Icon }: { label: string; value: string; icon: any }) {
  return (
    <div className="rounded-2xl border bg-card p-4">
      <div className="flex items-center justify-between">
        <div className="text-[11px] text-muted-foreground">{label}</div>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </div>
      <div className="mt-1.5 text-lg font-display font-semibold">{value}</div>
    </div>
  );
}
