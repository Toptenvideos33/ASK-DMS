import { createFileRoute } from "@tanstack/react-router";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PackageMinus, ArrowRightLeft } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/stock-out")({ component: StockOutPage });

function StockOutPage() {
  const { products, lorryStock, setLorryStock, stockOut } = useStore();

  const lorryFor = (id: string) => lorryStock.find((l) => l.productId === id)?.units ?? 0;
  const totalUnits = lorryStock.reduce((s, l) => s + l.units, 0);

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <div className="text-xs uppercase tracking-wider text-muted-foreground">Day-End</div>
        <h1 className="text-3xl font-semibold mt-1">Stock Out — Lorry to Warehouse</h1>
        <p className="text-sm text-muted-foreground mt-1">Review remaining lorry stock and return unsold units to main warehouse.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="p-5">
          <div className="text-xs text-muted-foreground">Remaining on Lorry</div>
          <div className="mt-2 text-3xl font-display font-semibold">{totalUnits.toLocaleString()}</div>
          <div className="text-xs text-muted-foreground">total units across SKUs</div>
        </Card>
        <Card className="p-5 md:col-span-2 flex items-center justify-between">
          <div>
            <div className="font-semibold">Run Day-End Stock Out</div>
            <div className="text-xs text-muted-foreground mt-1">Moves all remaining lorry units into main warehouse and resets lorry to zero.</div>
          </div>
          <Button
            onClick={() => {
              if (totalUnits === 0) return toast.info("Lorry is already empty");
              stockOut();
              toast.success("Stock returned to warehouse");
            }}
            className="gap-1.5"
          >
            <ArrowRightLeft className="h-4 w-4" /> Return to Warehouse
          </Button>
        </Card>
      </div>

      <Card className="overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/60 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="text-left px-4 py-3">Product</th>
                <th className="text-right px-4 py-3">Warehouse (units)</th>
                <th className="text-right px-4 py-3">On Lorry (units)</th>
                <th className="text-right px-4 py-3">Adjust Lorry</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {products.map((p) => {
                const onLorry = lorryFor(p.id);
                return (
                  <tr key={p.id}>
                    <td className="px-4 py-3">
                      <div className="font-medium">{p.name}</div>
                      <div className="text-xs text-muted-foreground">{p.sku}</div>
                    </td>
                    <td className="px-4 py-3 text-right">{p.stock}</td>
                    <td className="px-4 py-3 text-right">
                      <span className={`inline-flex items-center gap-1 ${onLorry > 0 ? "text-primary font-medium" : "text-muted-foreground"}`}>
                        <PackageMinus className="h-3.5 w-3.5" /> {onLorry}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <Input
                        type="number"
                        className="w-28 ml-auto text-right"
                        value={onLorry}
                        onChange={(e) => setLorryStock(p.id, Math.max(0, +e.target.value))}
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
