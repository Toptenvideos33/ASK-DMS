import { createFileRoute, Link } from "@tanstack/react-router";
import { useStore, formatLKR, qtyLabel } from "@/lib/store";

export const Route = createFileRoute("/driver/bills")({ component: BillsList });

function BillsList() {
  const { bills, products } = useStore();
  return (
    <div className="p-5 space-y-3">
      <h1 className="font-display text-xl font-semibold">Bills</h1>
      {bills.length === 0 && (
        <div className="rounded-xl border bg-card p-6 text-center text-sm text-muted-foreground">No bills yet.</div>
      )}
      {bills.map((b) => (
        <div key={b.id} className="rounded-xl border bg-card p-4">
          <div className="flex justify-between">
            <div>
              <div className="font-semibold text-sm">{b.invoiceNo}</div>
              <div className="text-xs text-muted-foreground">{b.shopName}</div>
            </div>
            <div className="text-right">
              <div className="font-semibold text-sm">{formatLKR(b.total)}</div>
              <span className="text-[10px] rounded-full bg-muted px-2 py-0.5">{b.paymentMethod}</span>
            </div>
          </div>
          <div className="mt-2 text-xs text-muted-foreground">
            {b.items.map((it) => {
              const p = products.find((x) => x.id === it.productId);
              return `${p?.name ?? ""} (${qtyLabel(it.cases, it.units)})`;
            }).join(", ")}
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px]">
            <span className="text-muted-foreground">{new Date(b.createdAt).toLocaleString()}</span>
            {b.notified ? (
              <span className="text-success">✓ Notified</span>
            ) : (
              <Link to="/driver/new-bill" className="text-primary">—</Link>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
