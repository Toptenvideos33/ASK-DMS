import { createFileRoute, Link } from "@tanstack/react-router";
import { useStore, formatLKR } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Package, Truck, Users, ReceiptText, ArrowUpRight } from "lucide-react";

export const Route = createFileRoute("/admin/")({
  component: Dashboard,
});

function Dashboard() {
  const { products, vehicles, drivers, bills, lorryStock } = useStore();

  const totalRevenue = bills.reduce((s, b) => s + b.total, 0);
  const totalUnitsOnLorry = lorryStock.reduce((s, l) => s + l.units, 0);
  const lowStock = products.filter((p) => p.stock < p.unitsPerCase * 2).length;

  const stats = [
    { label: "Today's Revenue", value: formatLKR(totalRevenue), icon: ReceiptText, accent: "text-primary", bg: "bg-primary/10" },
    { label: "Products", value: products.length, icon: Package, accent: "text-success", bg: "bg-success/10" },
    { label: "Active Fleet", value: vehicles.length, icon: Truck, accent: "text-warning", bg: "bg-warning/10" },
    { label: "Drivers", value: drivers.length, icon: Users, accent: "text-accent-foreground", bg: "bg-accent" },
  ];

  return (
    <div className="space-y-8 max-w-7xl">
      <div className="flex items-end justify-between">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Overview</div>
          <h1 className="text-3xl font-semibold mt-1">Dashboard</h1>
        </div>
        <Link to="/driver" className="hidden md:inline-flex items-center gap-1.5 rounded-md border bg-card px-3 py-2 text-sm hover:bg-muted">
          Open Driver App <ArrowUpRight className="h-4 w-4" />
        </Link>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label} className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <div className="text-xs text-muted-foreground">{s.label}</div>
                <div className="mt-2 text-2xl font-semibold font-display">{s.value}</div>
              </div>
              <div className={`grid h-10 w-10 place-items-center rounded-lg ${s.bg}`}>
                <s.icon className={`h-5 w-5 ${s.accent}`} />
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2 p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Recent Bills</h2>
            <Link to="/admin/reports" className="text-sm text-primary hover:underline">View all</Link>
          </div>
          <div className="mt-4 divide-y">
            {bills.length === 0 && (
              <div className="py-10 text-center text-sm text-muted-foreground">
                No bills yet. Open the driver app to create one.
              </div>
            )}
            {bills.slice(0, 6).map((b) => (
              <div key={b.id} className="py-3 flex items-center justify-between">
                <div>
                  <div className="font-medium">{b.invoiceNo} <span className="text-muted-foreground font-normal">· {b.shopName}</span></div>
                  <div className="text-xs text-muted-foreground">{new Date(b.createdAt).toLocaleString()} · {b.paymentMethod}</div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">{formatLKR(b.total)}</div>
                  <div className="text-[11px] text-muted-foreground">{b.items.length} item{b.items.length !== 1 && "s"}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-lg font-semibold">Lorry Snapshot</h2>
          <div className="mt-2 text-xs text-muted-foreground">Units currently loaded on vehicles</div>
          <div className="mt-5 text-4xl font-display font-semibold">{totalUnitsOnLorry.toLocaleString()}</div>
          <div className="text-xs text-muted-foreground">total loose units</div>
          <div className="mt-6 rounded-lg bg-muted p-3 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Low stock SKUs</span><span className="font-medium">{lowStock}</span></div>
          </div>
          <Link to="/admin/stock-out" className="mt-4 block rounded-md bg-primary px-3 py-2 text-center text-sm font-medium text-primary-foreground hover:opacity-95">Day-End Stock Out</Link>
        </Card>
      </div>
    </div>
  );
}
