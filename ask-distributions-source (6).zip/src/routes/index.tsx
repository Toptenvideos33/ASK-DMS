import { createFileRoute, Link } from "@tanstack/react-router";
import { Truck, LayoutDashboard, Smartphone, Package, MapPin } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ASK Distributions — DMS" },
      { name: "description", content: "Choose Admin Panel or Driver App. Distribution Management System built for Sri Lankan distributors." },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen bg-[var(--gradient-subtle)]">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <div className="flex items-center gap-2">
          <div className="grid h-9 w-9 place-items-center rounded-lg bg-primary text-primary-foreground">
            <Truck className="h-5 w-5" />
          </div>
          <div className="font-display text-lg font-semibold">ASK Distributions</div>
        </div>
        <div className="text-sm text-muted-foreground">Colombo, Sri Lanka</div>
      </header>

      <main className="mx-auto max-w-6xl px-6 pt-10 pb-20">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 rounded-full border bg-card px-3 py-1 text-xs text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-success" /> Distribution Management System
          </div>
          <h1 className="mt-4 text-5xl font-semibold leading-[1.05] tracking-tight">
            Move stock. Bill on the road.<br/>
            <span className="text-primary">Close the day clean.</span>
          </h1>
          <p className="mt-4 max-w-xl text-muted-foreground">
            Manage products, vehicles, routes and drivers from one panel. Let drivers bill on mobile,
            notify shop owners via WhatsApp, and reconcile lorry stock at day-end — all in LKR.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2">
          <Link
            to="/admin"
            className="group relative overflow-hidden rounded-2xl border bg-card p-8 shadow-[var(--shadow-soft)] transition hover:shadow-[var(--shadow-elevated)]"
          >
            <div className="flex items-center justify-between">
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-primary/10 text-primary">
                <LayoutDashboard className="h-6 w-6" />
              </div>
              <span className="text-xs font-medium text-muted-foreground">Web</span>
            </div>
            <h2 className="mt-6 text-2xl font-semibold">Admin Panel</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Products with cases & loose units, vehicles, routes, drivers, reports, settings and day-end stock-out.
            </p>
            <div className="mt-6 flex items-center gap-3 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1"><Package className="h-3.5 w-3.5" /> Inventory</span>
              <span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5" /> Routes</span>
            </div>
            <div className="mt-6 text-sm font-medium text-primary">Open Admin →</div>
          </Link>

          <Link
            to="/driver"
            className="group relative overflow-hidden rounded-2xl border p-8 text-primary-foreground shadow-[var(--shadow-soft)] transition hover:shadow-[var(--shadow-elevated)]"
            style={{ background: "var(--gradient-primary)" }}
          >
            <div className="flex items-center justify-between">
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-white/15">
                <Smartphone className="h-6 w-6" />
              </div>
              <span className="text-xs font-medium opacity-80">Mobile</span>
            </div>
            <h2 className="mt-6 text-2xl font-semibold">Driver App</h2>
            <p className="mt-2 text-sm opacity-90">
              Bill on the road with cases + loose units, auto-applied FOC and discounts, payment selection,
              WhatsApp notification, and Woosim 58/80mm receipts.
            </p>
            <div className="mt-6 text-sm font-medium">Open Driver App →</div>
          </Link>
        </div>
      </main>
    </div>
  );
}
