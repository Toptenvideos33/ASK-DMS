import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useStore, formatLKR, type Product } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, Gift, Percent } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/products")({ component: ProductsPage });

const empty = {
  name: "", sku: "", category: "",
  unitsPerCase: 24, pricePerCase: 0, pricePerUnit: 0, stock: 0,
  focBuyCases: 0, focFreeUnits: 0, discountMinCases: 0, discountPercent: 0,
};

function ProductsPage() {
  const { products, addProduct, updateProduct, deleteProduct } = useStore();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [form, setForm] = useState({ ...empty });

  const openNew = () => { setEditing(null); setForm({ ...empty }); setOpen(true); };
  const openEdit = (p: Product) => {
    setEditing(p);
    setForm({
      name: p.name, sku: p.sku, category: p.category,
      unitsPerCase: p.unitsPerCase, pricePerCase: p.pricePerCase, pricePerUnit: p.pricePerUnit, stock: p.stock,
      focBuyCases: p.focBuyCases ?? 0, focFreeUnits: p.focFreeUnits ?? 0,
      discountMinCases: p.discountMinCases ?? 0, discountPercent: p.discountPercent ?? 0,
    });
    setOpen(true);
  };

  const save = () => {
    if (!form.name.trim() || !form.sku.trim()) { toast.error("Name and SKU are required"); return; }
    const payload = {
      ...form,
      focBuyCases: form.focBuyCases || undefined,
      focFreeUnits: form.focFreeUnits || undefined,
      discountMinCases: form.discountMinCases || undefined,
      discountPercent: form.discountPercent || undefined,
    };
    if (editing) { updateProduct(editing.id, payload); toast.success("Product updated"); }
    else { addProduct(payload); toast.success("Product added"); }
    setOpen(false);
  };

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex items-end justify-between">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Inventory</div>
          <h1 className="text-3xl font-semibold mt-1">Products</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage SKUs with case + unit pricing, FOC and discount rules.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button onClick={openNew}><Plus className="h-4 w-4 mr-1" /> Add Product</Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader><DialogTitle>{editing ? "Edit Product" : "New Product"}</DialogTitle></DialogHeader>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Name"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
              <Field label="SKU"><Input value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} /></Field>
              <Field label="Category"><Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} /></Field>
              <Field label="Units per Case"><Input type="number" value={form.unitsPerCase} onChange={(e) => setForm({ ...form, unitsPerCase: +e.target.value })} /></Field>
              <Field label="Price per Case (Rs.)"><Input type="number" value={form.pricePerCase} onChange={(e) => setForm({ ...form, pricePerCase: +e.target.value })} /></Field>
              <Field label="Price per Unit (Rs.)"><Input type="number" value={form.pricePerUnit} onChange={(e) => setForm({ ...form, pricePerUnit: +e.target.value })} /></Field>
              <Field label="Stock (units, warehouse)"><Input type="number" value={form.stock} onChange={(e) => setForm({ ...form, stock: +e.target.value })} /></Field>
              <div className="sm:col-span-2 pt-2">
                <div className="text-xs font-semibold uppercase text-muted-foreground tracking-wider mb-2 flex items-center gap-1.5">
                  <Gift className="h-3.5 w-3.5" /> Free-of-Cost rule (auto-applied in driver cart)
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Buy (Cases)"><Input type="number" value={form.focBuyCases} onChange={(e) => setForm({ ...form, focBuyCases: +e.target.value })} /></Field>
                  <Field label="Get Free (Units)"><Input type="number" value={form.focFreeUnits} onChange={(e) => setForm({ ...form, focFreeUnits: +e.target.value })} /></Field>
                </div>
              </div>
              <div className="sm:col-span-2">
                <div className="text-xs font-semibold uppercase text-muted-foreground tracking-wider mb-2 flex items-center gap-1.5">
                  <Percent className="h-3.5 w-3.5" /> Discount rule
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Min Cases"><Input type="number" value={form.discountMinCases} onChange={(e) => setForm({ ...form, discountMinCases: +e.target.value })} /></Field>
                  <Field label="Discount %"><Input type="number" value={form.discountPercent} onChange={(e) => setForm({ ...form, discountPercent: +e.target.value })} /></Field>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={save}>{editing ? "Save changes" : "Add product"}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/60 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="text-left px-4 py-3">Product</th>
                <th className="text-left px-4 py-3">Category</th>
                <th className="text-right px-4 py-3">Units/Case</th>
                <th className="text-right px-4 py-3">Case Price</th>
                <th className="text-right px-4 py-3">Unit Price</th>
                <th className="text-right px-4 py-3">Stock (units)</th>
                <th className="text-left px-4 py-3">Rules</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {products.map((p) => (
                <tr key={p.id} className="hover:bg-muted/30">
                  <td className="px-4 py-3">
                    <div className="font-medium">{p.name}</div>
                    <div className="text-xs text-muted-foreground">{p.sku}</div>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{p.category}</td>
                  <td className="px-4 py-3 text-right">{p.unitsPerCase}</td>
                  <td className="px-4 py-3 text-right">{formatLKR(p.pricePerCase)}</td>
                  <td className="px-4 py-3 text-right">{formatLKR(p.pricePerUnit)}</td>
                  <td className="px-4 py-3 text-right">{p.stock}</td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap gap-1">
                      {p.focBuyCases && p.focFreeUnits ? (
                        <span className="rounded-full bg-success/10 px-2 py-0.5 text-[11px] text-success">FOC {p.focBuyCases}C → {p.focFreeUnits}U</span>
                      ) : null}
                      {p.discountMinCases && p.discountPercent ? (
                        <span className="rounded-full bg-warning/15 px-2 py-0.5 text-[11px] text-warning-foreground">{p.discountPercent}% @ {p.discountMinCases}C</span>
                      ) : null}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex justify-end gap-1">
                      <Button size="icon" variant="ghost" onClick={() => openEdit(p)}><Pencil className="h-4 w-4" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => { deleteProduct(p.id); toast.success("Deleted"); }}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs">{label}</Label>
      {children}
    </div>
  );
}
