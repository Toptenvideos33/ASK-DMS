import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, Trash2, User, Phone } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/drivers")({ component: DriversPage });

function DriversPage() {
  const { drivers, vehicles, routes, addDriver, deleteDriver } = useStore();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", vehicleId: "", routeId: "" });

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex items-end justify-between">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Team</div>
          <h1 className="text-3xl font-semibold mt-1">Drivers</h1>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> Add Driver</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>New Driver</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label className="text-xs">Full Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div><Label className="text-xs">Phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+94 7X XXX XXXX" /></div>
              <div>
                <Label className="text-xs">Vehicle</Label>
                <select className="mt-1 w-full rounded-md border bg-background px-3 py-2 text-sm" value={form.vehicleId} onChange={(e) => setForm({ ...form, vehicleId: e.target.value })}>
                  <option value="">None</option>
                  {vehicles.map((v) => <option key={v.id} value={v.id}>{v.number}</option>)}
                </select>
              </div>
              <div>
                <Label className="text-xs">Route</Label>
                <select className="mt-1 w-full rounded-md border bg-background px-3 py-2 text-sm" value={form.routeId} onChange={(e) => setForm({ ...form, routeId: e.target.value })}>
                  <option value="">None</option>
                  {routes.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                </select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={() => { if (!form.name) return toast.error("Name required"); addDriver({ ...form, vehicleId: form.vehicleId || undefined, routeId: form.routeId || undefined }); toast.success("Added"); setOpen(false); setForm({ name: "", phone: "", vehicleId: "", routeId: "" }); }}>Add</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {drivers.map((d) => {
          const v = vehicles.find((x) => x.id === d.vehicleId);
          const r = routes.find((x) => x.id === d.routeId);
          return (
            <Card key={d.id} className="p-5">
              <div className="flex items-start justify-between">
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-accent text-accent-foreground"><User className="h-5 w-5" /></div>
                <Button size="icon" variant="ghost" onClick={() => deleteDriver(d.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
              <div className="mt-4 font-display text-lg font-semibold">{d.name}</div>
              <div className="mt-1 text-sm text-muted-foreground flex items-center gap-1.5"><Phone className="h-3.5 w-3.5" /> {d.phone}</div>
              <div className="mt-3 space-y-1.5 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">Vehicle</span><span className="font-medium">{v?.number ?? "—"}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Route</span><span className="font-medium">{r?.name ?? "—"}</span></div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
