import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, Trash2, MapPin } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/routes")({ component: RoutesPage });

function RoutesPage() {
  const { routes, addRoute, deleteRoute } = useStore();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", area: "", stops: 10 });

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex items-end justify-between">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Delivery</div>
          <h1 className="text-3xl font-semibold mt-1">Routes</h1>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> Add Route</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>New Route</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label className="text-xs">Route Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div><Label className="text-xs">Area / Path</Label><Input value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })} placeholder="A → B → C" /></div>
              <div><Label className="text-xs">Number of Stops</Label><Input type="number" value={form.stops} onChange={(e) => setForm({ ...form, stops: +e.target.value })} /></div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={() => { if (!form.name) return toast.error("Name required"); addRoute(form); toast.success("Added"); setOpen(false); setForm({ name: "", area: "", stops: 10 }); }}>Add</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {routes.map((r) => (
          <Card key={r.id} className="p-5">
            <div className="flex items-start justify-between">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary"><MapPin className="h-5 w-5" /></div>
              <Button size="icon" variant="ghost" onClick={() => deleteRoute(r.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
            </div>
            <div className="mt-4 font-display text-lg font-semibold">{r.name}</div>
            <div className="text-sm text-muted-foreground mt-1">{r.area}</div>
            <div className="mt-3 inline-flex rounded-full bg-muted px-2.5 py-0.5 text-xs">{r.stops} stops</div>
          </Card>
        ))}
      </div>
    </div>
  );
}
