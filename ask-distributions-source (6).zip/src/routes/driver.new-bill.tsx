import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useStore, formatLKR, computeLineTotal, qtyLabel, type BillItem, type PaymentMethod, type Bill } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Plus, Minus, Trash2, Search, ShoppingCart, MessageCircle, CheckCircle2, Printer, ArrowLeft } from "lucide-react";
import { Receipt } from "@/components/Receipt";
import { toast } from "sonner";

export const Route = createFileRoute("/driver/new-bill")({ component: NewBill });

type CartEntry = { productId: string; cases: number; units: number };
type Step = "cart" | "shop" | "payment" | "notify" | "receipt";

function NewBill() {
  const { products, settings, drivers, saveBill, markBillNotified } = useStore();
  const driver = drivers[0];

  const [step, setStep] = useState<Step>("cart");
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState<CartEntry[]>([]);
  const [shop, setShop] = useState({ name: "", phone: "", address: "" });
  const [payment, setPayment] = useState<PaymentMethod | null>(null);
  const [savedBill, setSavedBill] = useState<Bill | null>(null);
  const [receiptSize, setReceiptSize] = useState<58 | 80>(80);

  const filtered = products.filter(
    (p) => !search.trim() || p.name.toLowerCase().includes(search.toLowerCase()) || p.sku.toLowerCase().includes(search.toLowerCase())
  );

  const updateEntry = (productId: string, patch: Partial<CartEntry>) => {
    setCart((c) => {
      const exists = c.find((x) => x.productId === productId);
      if (!exists) return [...c, { productId, cases: 0, units: 0, ...patch }];
      return c.map((x) => (x.productId === productId ? { ...x, ...patch } : x));
    });
  };

  const removeEntry = (productId: string) =>
    setCart((c) => c.filter((x) => x.productId !== productId));

  const computedItems: BillItem[] = useMemo(
    () =>
      cart
        .filter((c) => c.cases > 0 || c.units > 0)
        .map((c) => {
          const p = products.find((x) => x.id === c.productId)!;
          const { focUnits, discountPercent, lineTotal } = computeLineTotal(p, c.cases, c.units);
          return { productId: c.productId, cases: c.cases, units: c.units, focUnits, discountPercent, lineTotal };
        }),
    [cart, products]
  );

  const subtotal = computedItems.reduce((s, it) => s + it.lineTotal, 0);
  const taxAmount = subtotal * (settings.taxPercent / 100);
  const total = subtotal + taxAmount;

  const confirmBill = () => {
    if (!payment) return toast.error("Select a payment method");
    const bill = saveBill({
      driverId: driver?.id ?? "",
      shopName: shop.name, shopPhone: shop.phone, shopAddress: shop.address,
      items: computedItems, subtotal, taxPercent: settings.taxPercent, taxAmount, total,
      paymentMethod: payment, notified: false,
    });
    setSavedBill(bill);
    setStep("notify");
  };

  const sendNotification = () => {
    if (!savedBill) return;
    // Simulated WhatsApp/SMS
    setTimeout(() => {
      markBillNotified(savedBill.id);
      setSavedBill({ ...savedBill, notified: true });
      toast.success("WhatsApp notification sent to " + (shop.phone || "shop"));
    }, 800);
  };

  // ============ STEPS ============

  if (step === "cart") {
    return (
      <div className="p-5 space-y-4">
        <div>
          <h1 className="font-display text-xl font-semibold">New Bill</h1>
          <p className="text-xs text-muted-foreground">Add products with Cases and Loose Units.</p>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search products" className="pl-9" />
        </div>

        <div className="space-y-2">
          {filtered.map((p) => {
            const entry = cart.find((c) => c.productId === p.id) ?? { productId: p.id, cases: 0, units: 0 };
            const hasQty = entry.cases > 0 || entry.units > 0;
            const { focUnits, discountPercent, lineTotal } = hasQty ? computeLineTotal(p, entry.cases, entry.units) : { focUnits: 0, discountPercent: 0, lineTotal: 0 };
            return (
              <Card key={p.id} className="p-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="font-medium text-sm truncate">{p.name}</div>
                    <div className="text-[11px] text-muted-foreground">{p.unitsPerCase}/case · {formatLKR(p.pricePerCase)} case · {formatLKR(p.pricePerUnit)} unit</div>
                    {(p.focBuyCases && p.focFreeUnits) || (p.discountMinCases && p.discountPercent) ? (
                      <div className="mt-1 flex flex-wrap gap-1">
                        {p.focBuyCases && p.focFreeUnits ? (<span className="rounded-full bg-success/10 px-1.5 py-0.5 text-[10px] text-success">FOC {p.focBuyCases}C→{p.focFreeUnits}U</span>) : null}
                        {p.discountMinCases && p.discountPercent ? (<span className="rounded-full bg-warning/15 px-1.5 py-0.5 text-[10px]">-{p.discountPercent}% @ {p.discountMinCases}C</span>) : null}
                      </div>
                    ) : null}
                  </div>
                  {hasQty && (
                    <div className="text-right shrink-0">
                      <div className="font-semibold text-sm">{formatLKR(lineTotal)}</div>
                      <div className="text-[10px] text-muted-foreground">{qtyLabel(entry.cases, entry.units)}</div>
                    </div>
                  )}
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <Stepper label="Cases" value={entry.cases} onChange={(v) => updateEntry(p.id, { units: entry.units, cases: v })} />
                  <Stepper label="Units" value={entry.units} onChange={(v) => updateEntry(p.id, { cases: entry.cases, units: v })} />
                </div>
                {(focUnits > 0 || discountPercent > 0) && (
                  <div className="mt-2 rounded-md bg-success/10 px-2 py-1 text-[11px] text-success">
                    {focUnits > 0 && <span>✓ +{focUnits} FOC units </span>}
                    {discountPercent > 0 && <span>✓ {discountPercent}% off auto-applied</span>}
                  </div>
                )}
              </Card>
            );
          })}
        </div>

        {computedItems.length > 0 && (
          <div className="sticky bottom-20 -mx-5 px-5">
            <div className="rounded-2xl bg-foreground text-background p-4 shadow-[var(--shadow-elevated)] flex items-center justify-between">
              <div>
                <div className="text-[11px] opacity-70">{computedItems.length} item{computedItems.length > 1 && "s"} · Subtotal</div>
                <div className="text-lg font-semibold">{formatLKR(total)}</div>
              </div>
              <Button onClick={() => setStep("shop")} className="gap-1.5">
                <ShoppingCart className="h-4 w-4" /> Review
              </Button>
            </div>
          </div>
        )}
      </div>
    );
  }

  if (step === "shop") {
    return (
      <div className="p-5 space-y-4">
        <button onClick={() => setStep("cart")} className="inline-flex items-center gap-1 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" /> Back</button>
        <h1 className="font-display text-xl font-semibold">Customer Details</h1>

        <Card className="p-4 space-y-3">
          <div><Label className="text-xs">Shop Name</Label><Input value={shop.name} onChange={(e) => setShop({ ...shop, name: e.target.value })} placeholder="e.g. New City Stores" /></div>
          <div><Label className="text-xs">Phone (for WhatsApp)</Label><Input value={shop.phone} onChange={(e) => setShop({ ...shop, phone: e.target.value })} placeholder="+94 7X XXX XXXX" /></div>
          <div><Label className="text-xs">Address (optional)</Label><Input value={shop.address} onChange={(e) => setShop({ ...shop, address: e.target.value })} /></div>
        </Card>

        <Card className="p-4">
          <div className="text-xs font-semibold uppercase text-muted-foreground tracking-wider mb-2">Order Summary</div>
          {computedItems.map((it) => {
            const p = products.find((x) => x.id === it.productId)!;
            return (
              <div key={it.productId} className="flex justify-between text-sm py-1.5 border-b last:border-0">
                <div>
                  <div>{p.name}</div>
                  <div className="text-[11px] text-muted-foreground">{qtyLabel(it.cases, it.units)}{it.focUnits ? ` + ${it.focUnits}U FOC` : ""}{it.discountPercent ? ` · -${it.discountPercent}%` : ""}</div>
                </div>
                <div className="font-medium">{formatLKR(it.lineTotal)}</div>
              </div>
            );
          })}
          <div className="mt-3 space-y-1 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>{formatLKR(subtotal)}</span></div>
            {taxAmount > 0 && <div className="flex justify-between"><span className="text-muted-foreground">{settings.taxLabel} {settings.taxPercent}%</span><span>{formatLKR(taxAmount)}</span></div>}
            <div className="flex justify-between font-display text-base font-semibold pt-2 border-t mt-1"><span>Total</span><span>{formatLKR(total)}</span></div>
          </div>
        </Card>

        <Button className="w-full" onClick={() => { if (!shop.name) return toast.error("Shop name required"); setStep("payment"); }}>Continue to Payment</Button>
      </div>
    );
  }

  if (step === "payment") {
    const methods: PaymentMethod[] = ["Cash", "Credit", "Cheque", "Bank Transfer"];
    return (
      <div className="p-5 space-y-4">
        <button onClick={() => setStep("shop")} className="inline-flex items-center gap-1 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" /> Back</button>
        <h1 className="font-display text-xl font-semibold">Payment Method</h1>
        <p className="text-sm text-muted-foreground">Total payable: <b className="text-foreground">{formatLKR(total)}</b></p>
        <div className="grid grid-cols-2 gap-3">
          {methods.map((m) => (
            <button
              key={m}
              onClick={() => setPayment(m)}
              className={`rounded-2xl border p-4 text-left transition ${payment === m ? "border-primary bg-primary/5 ring-2 ring-primary/30" : "bg-card hover:bg-muted/40"}`}
            >
              <div className="font-semibold">{m}</div>
              <div className="text-[11px] text-muted-foreground mt-1">{m === "Cash" ? "Collect now" : m === "Credit" ? "Pay later" : m === "Cheque" ? "Record cheque #" : "Direct transfer"}</div>
            </button>
          ))}
        </div>
        <Button className="w-full" disabled={!payment} onClick={confirmBill}>Confirm Bill</Button>
      </div>
    );
  }

  if (step === "notify" && savedBill) {
    return (
      <div className="p-5 space-y-4">
        <h1 className="font-display text-xl font-semibold">Notify Customer</h1>
        <Card className="p-5 text-center">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-success/10 text-success">
            <CheckCircle2 className="h-7 w-7" />
          </div>
          <div className="mt-3 font-semibold">Bill {savedBill.invoiceNo} confirmed</div>
          <div className="text-xs text-muted-foreground mt-1">{formatLKR(savedBill.total)} · {savedBill.paymentMethod}</div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <MessageCircle className="h-4 w-4 text-[#25D366]" /> WhatsApp / SMS to {shop.phone || "shop"}
          </div>
          <div className="mt-3 rounded-lg bg-muted p-3 text-xs whitespace-pre-line font-mono">
{`Hi ${shop.name},
Thank you for your order from ${settings.businessName}.
Invoice: ${savedBill.invoiceNo}
Items: ${savedBill.items.length}
Total: ${formatLKR(savedBill.total)}
Payment: ${savedBill.paymentMethod}
— ${settings.phone1}`}
          </div>
          {!savedBill.notified ? (
            <Button className="w-full mt-3 bg-[#25D366] hover:bg-[#1ebe5c] text-white" onClick={sendNotification}>
              Send Notification
            </Button>
          ) : (
            <div className="mt-3 rounded-md bg-success/10 px-3 py-2 text-sm text-success flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4" /> Notification sent successfully
            </div>
          )}
        </Card>

        {savedBill.notified && (
          <Button className="w-full gap-1.5" onClick={() => setStep("receipt")}>
            <Printer className="h-4 w-4" /> Print Receipt
          </Button>
        )}
      </div>
    );
  }

  if (step === "receipt" && savedBill) {
    return (
      <div className="p-5 space-y-4">
        <h1 className="font-display text-xl font-semibold">Receipt Preview</h1>
        <div className="flex gap-2">
          <button onClick={() => setReceiptSize(58)} className={`flex-1 rounded-lg border px-3 py-2 text-sm ${receiptSize === 58 ? "bg-primary text-primary-foreground border-primary" : "bg-card"}`}>58mm (2")</button>
          <button onClick={() => setReceiptSize(80)} className={`flex-1 rounded-lg border px-3 py-2 text-sm ${receiptSize === 80 ? "bg-primary text-primary-foreground border-primary" : "bg-card"}`}>80mm (3")</button>
        </div>
        <div className="rounded-xl bg-muted p-4 grid place-items-center">
          <div className="receipt-print bg-white shadow-md">
            <Receipt bill={savedBill} width={receiptSize} />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Button variant="outline" onClick={() => window.print()} className="gap-1.5"><Printer className="h-4 w-4" /> Print</Button>
          <Link to="/driver" className="rounded-md bg-primary text-primary-foreground px-4 py-2 text-sm font-medium text-center">Done</Link>
        </div>
        <p className="text-[11px] text-muted-foreground text-center">Optimized for Woosim thermal printers (58mm / 80mm).</p>
      </div>
    );
  }

  return null;
}

function Stepper({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div>
      <div className="text-[11px] text-muted-foreground mb-1">{label}</div>
      <div className="flex items-center rounded-lg border bg-card">
        <button onClick={() => onChange(Math.max(0, value - 1))} className="grid h-9 w-9 place-items-center text-muted-foreground hover:bg-muted"><Minus className="h-4 w-4" /></button>
        <input
          type="number"
          value={value}
          onChange={(e) => onChange(Math.max(0, +e.target.value))}
          className="w-full h-9 text-center bg-transparent outline-none text-sm font-medium"
        />
        <button onClick={() => onChange(value + 1)} className="grid h-9 w-9 place-items-center text-muted-foreground hover:bg-muted"><Plus className="h-4 w-4" /></button>
      </div>
    </div>
  );
}
